/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex02_cha_sorinoks;

/**
 *
 * @author Kiley
 */
public class Singer {
    
    String name, favSong;
    int noOfPerformances;
    double earnings;
    
    public Singer(String n, int num, double earn, String s){
        name = n;
        noOfPerformances = num;
        earnings = earn;
        favSong = s;
    }
    
    public void performForAudience(int numOfPeople){
        System.out.println("===");
        System.out.println("Before: ");
        System.out.println("Performances: " + noOfPerformances);
        System.out.println("Earnings: " + earnings);
        noOfPerformances = noOfPerformances + 1;
        earnings = earnings + 100*numOfPeople;
        System.out.println(" ");
        System.out.println("After: ");
        System.out.println("Performances: " + noOfPerformances);
        System.out.println("Earnings: " + earnings);
        System.out.println(" ");
    }

    public void changeFavSong(String newSong){
        System.out.println("===");
        System.out.println("Previous Favorite Song: " + favSong);
        favSong = newSong;
        System.out.println("New Favorite Song: " + favSong);
        System.out.println(" ");
    }
    
}
