/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercise09charmsorinokiley;

/**
 *
 * @author Kiley
 */
public class FullTeamException extends Exception {
    public FullTeamException(){
    }
    
    public FullTeamException(String msg){
        super(msg);
    }
}
