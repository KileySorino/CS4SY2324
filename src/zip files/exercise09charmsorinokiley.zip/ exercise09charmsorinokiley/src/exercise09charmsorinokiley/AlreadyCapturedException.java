/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercise09charmsorinokiley;

/**
 *
 * @author Kiley
 */
public class AlreadyCapturedException extends Exception {
    public AlreadyCapturedException(){
    }
    
    public AlreadyCapturedException(String msg){
        super(msg);
    }
}
