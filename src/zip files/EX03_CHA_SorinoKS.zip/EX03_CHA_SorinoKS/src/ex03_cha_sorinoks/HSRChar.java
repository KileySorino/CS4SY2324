/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ex03_cha_sorinoks;

/**
 *
 * @author Kiley
 */


public class HSRChar{
    private String name, location, path, combattype;
    private int rarity;
    
    public HSRChar(String n, String l, int r, String p, String c){
    name = n;
    location = l;
    rarity = r;
    path = p;
    combattype = c;
    }
}
