/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package CS4CharmSorino_Q1Ex1;

/**
 *
 * @author Kiley
 */
public class CS4CharmSorino_Q1Ex1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        boolean isPomuOlder, PomuFinanaSpecies;
        int howMuchTallerIsElira;
                
        //name, age, height, birthday, species
        
     LazulightVtuber Vtuber1 = new LazulightVtuber();
     Vtuber1.num = 1;
     Vtuber1.name = "Pomu Rainpuff";
     Vtuber1.height = 156;
     Vtuber1.birthday = 07.12;
     Vtuber1.species = "Forest Fairy";
     
     LazulightVtuber Vtuber2 = new LazulightVtuber();
     Vtuber2.num = 2;
     Vtuber2.name = "Elira Pendora";
     Vtuber2.height = 160;
     Vtuber2.birthday = 10.16;
     Vtuber2.species = "Solar Sky Dragon";
     
     LazulightVtuber Vtuber3 = new LazulightVtuber();
     Vtuber3.num = 3;
     Vtuber3.name = "Finana Ryugu";
     Vtuber3.height = 140;
     Vtuber3.birthday = 06.21;
     Vtuber3.species = "Tropical Mermaid";
     
     Vtuberdetails(Vtuber1);
     Vtuberdetails(Vtuber2);
     Vtuberdetails(Vtuber3);
    
     
     isPomuOlder = Vtuber1.birthday < Vtuber2. birthday;
     howMuchTallerIsElira = Vtuber2.height - Vtuber3.height;
     PomuFinanaSpecies = Vtuber1.species.equals(Vtuber3.species);
     
    
     System.out.println("===");
     System.out.println("Is Pomu older than Elira? (Assuming they were born in the same year)");
     System.out.println(isPomuOlder + " - operation: comparison");

     
     System.out.println(" ");
     System.out.println("How much shorter is Finana compared to Elira?");
     System.out.println(howMuchTallerIsElira + "cm - operation: difference");

     
     System.out.println(" ");
     System.out.println("Are Pomu and Finana the same species?");
     System.out.println(PomuFinanaSpecies + " - operation: comparison");
     //false - operation: comparison

     
    }
    
    public static void Vtuberdetails(LazulightVtuber Vtuber){
            System.out.println("Lazulight Vtuber " + Vtuber.num);
            System.out.println("Name: " + Vtuber.name);
            System.out.println("Height: " + Vtuber.height);
            System.out.println("Birthday: " + Vtuber.birthday + "  (MM.DD)");
            System.out.println("Species: " + Vtuber.species);
            System.out.println(" ");
        }
  
    
}
