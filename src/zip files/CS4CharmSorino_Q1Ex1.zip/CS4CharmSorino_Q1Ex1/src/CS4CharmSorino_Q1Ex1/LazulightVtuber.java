/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CS4CharmSorino_Q1Ex1;

/**
 *
 * @author Kiley
 */
public class LazulightVtuber {
    int num;
    String name;
    int height;  
    //in cm and in human height
    double birthday;  
    //MM.DD (ex. 10.03 - October 3)
    String species;
  
}
